# Sparkbound Alpha 0.5 — Android build

Target: Godot 4.7.x (the included CI workflow uses 4.7.2), Compatibility renderer, landscape Android.

- Preset: `Android`
- Package: `com.sparkbound.alpha05`
- Version: `0.5.0` / code `5`
- Expected export name: `Sparkbound_Alpha05.apk`

The project includes `.github/workflows/android-build.yml` for a reproducible debug APK export using Godot 4.7.2 and the matching export templates.

Local desktop export requires Godot plus the Android export toolchain. Godot's 4.7 Android documentation requires the Android SDK and Java setup for desktop export; the project itself does not bundle those large external binaries.
