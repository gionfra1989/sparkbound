# Alpha 0.5 changes

## Fixed instead of hidden
- Restored all five original home entries.
- Rebuilt the drawing screen around a dedicated Android touch surface.
- Fixed the second/subsequent drawing-screen state so SKY does not inherit the previous pointer/stroke state.
- Prevented a closing drawing screen or old menu root from intercepting the next tap.
- Corrected Android orientation from portrait (`1`) to sensor landscape (`4`).
- Changed stretch policy to fixed 16:9 `keep` so touch/UI coordinates remain aligned on wide phones.
- Reduced the world road to exactly one wide road draw call.
- Kept Pencil, Marker and Crayon available instead of deleting them for younger players.
- Kept joystick control available in Guided mode; Luma guidance yields when the child touches the stick.
- Bridge must genuinely span both banks before it can be used.

## Story pass
- Tree creation now produces the first unexplained anomaly.
- Sky creation escalates the mystery with a shape moving against the wind.
- The bridge gains a dark echo beneath the water.
- Blanklings are framed as erased fragments rather than generic monsters.
- The companion leads to a Memory Fragment about the First Scribble's fear of erasure.
- Veyr ends Act I with the central mystery: `Who erased first?`
