# Sparkbound — Godot Alpha 0.5: The First Road

This is the Godot branch of Sparkbound. It does **not** use the old HTML/WebView game.

## Non-negotiable rules in this build
- Keep the five home entries: **New Adventure, Maker World, Hero Studio, Story Book, Community Worlds**.
- Never remove a control merely to call the game "simpler".
- Ages 4–5 get clearer guidance and fewer simultaneous decisions, but the joystick and drawing tools still work.
- The adventure uses **one continuous road**. The world script paints that road once, not as stacked wide roads.
- Every drawing quest creates a fresh drawing surface. Tree, sky, bridge, weapon and companion all use the same Android touch path.
- The child's drawing must visibly affect the game world.

## Act I — The White Vale
1. Veyr used the Great Eraser to trap the First Scribble; the Eraser also stripped colour and memory from the Vale.
2. Luma finds a new Maker.
3. Miro asks the Maker to reimagine a tree. The child's tree grows into the Vale and then behaves strangely.
4. Pip asks the Maker to reimagine the sky. The exact drawing becomes the moving sky, and one shape moves against the wind.
5. The road reaches an erased river crossing. The Maker draws one bridge from bank to bank and walks on the actual drawn line.
6. Something beneath the water imitates the bridge. Blanklings appear.
7. The Maker draws a weapon, then a companion.
8. The companion tracks a Memory Fragment revealing that the First Scribble was afraid of being erased.
9. At the Old Gate, Veyr asks the real question: **who erased first?**

## Android/input changes in Alpha 0.5
- Dedicated `DrawPad` touch surface instead of relying on leftover GUI event state.
- Raw `InputEventScreenTouch`/`InputEventScreenDrag` path for Android.
- Drawing input is disabled *before* a drawing screen closes so the old screen cannot steal the next tap.
- Each call to `setup()` clears the active pointer and all temporary strokes.
- Pencil, Marker, Crayon, Undo, Clear and Make It Real remain available.
- Bridge validation requires a left-bank-to-right-bank stroke.
- Old UI roots are removed from the tree immediately before freeing, avoiding invisible controls intercepting taps.
- Mobile orientation fixed to **sensor landscape**; the 1280×720 game keeps a fixed 16:9 layout.

## Home screen
All five entries open a real screen in this alpha. `New Adventure` is the complete vertical slice. Maker World and Hero Studio use the live drawing system; Story Book contains the Act I story; Community Worlds is an explicitly offline/safe preview rather than a dead button.

## Verification included
Run `python3 SMOKE_CHECK.py` to verify the project wiring, menu entries, drawing missions, sky callback, touch path, one-road rule, Android package/orientation and all referenced resources.

A GitHub Actions workflow is included at `.github/workflows/android-build.yml`; it imports the project with Godot 4.7.2 and exports an Android debug APK when run on a GitHub runner.
