from pathlib import Path
import re, sys, json
ROOT=Path(__file__).resolve().parent
errors=[]; checks=[]
def ok(name, cond, detail=''):
    checks.append((name, bool(cond), detail))
    if not cond: errors.append(name + (': '+detail if detail else ''))

game=(ROOT/'scripts/Game.gd').read_text()
draw=(ROOT/'scripts/DrawPad.gd').read_text()
world=(ROOT/'scripts/World.gd').read_text()
touch=(ROOT/'scripts/TouchUI.gd').read_text()
proj=(ROOT/'project.godot').read_text()

for label in ['NEW ADVENTURE','MAKER WORLD','HERO STUDIO','STORY BOOK','COMMUNITY WORLDS']:
    ok('menu '+label, label in game)
for kind in ['tree','sky','bridge','sword','dog']:
    ok('draw mission '+kind, f'_open_draw("{kind}"' in game)
ok('sky callback restores world', 'world.restore_sky(d)' in game and 'backdrop.sky_restored=true' in game)
ok('fresh Android touch path', 'func _input(event:InputEvent)' in draw and 'InputEventScreenTouch' in draw and 'set_input_as_handled' in draw)
ok('dedicated draw surface', 'draw_surface.gui_input.connect(_surface_input)' in draw)
ok('tools not hidden by age', 'pencil.visible = true' in draw and 'marker.visible = true' in draw and 'crayon.visible = true' in draw)
ok('guided joystick available', 'if not guided_mode' not in touch.split('func _draw()->void:',1)[1].split('func _button',1)[0])
ok('exactly one world road ribbon', world.count('draw_polyline(road_points') == 1, f"count={world.count('draw_polyline(road_points')}")
ok('no second wide title road', (ROOT/'scripts/Backdrop.gd').read_text().count('draw_polyline(road,') == 1)
ok('bridge crossing validation', 'bridge_ok' in draw and 'LEFT BANK' in draw and 'RIGHT BANK' in draw)
ok('Android package Alpha05', 'com.sparkbound.alpha05' in (ROOT/'export_presets.cfg').read_text())
ok('Godot project version', 'config/name="Sparkbound Alpha 0.5"' in proj)
ok('Android sensor-landscape orientation', 'window/handheld/orientation=4' in proj)
ok('fixed 16:9 stretch', 'window/stretch/aspect="keep"' in proj)
ok('drawing panel disables input before leaving', 'set_process_input(false)' in draw and 'func _cancel()' in draw)

# All preload/file references must exist.
for gd in (ROOT/'scripts').glob('*.gd'):
    txt=gd.read_text()
    for ref in re.findall(r'(?:preload|load)\("res://([^"]+)"\)', txt):
        ok('resource '+ref, (ROOT/ref).exists(), str(gd.name))
for ref in re.findall(r'path="res://([^"]+)"', (ROOT/'main.tscn').read_text()):
    ok('scene resource '+ref, (ROOT/ref).exists())

# Crude delimiter scanner catches accidental edit truncation while Godot binary is unavailable.
def scan(text, name):
    stack=[]; pairs={')':'(',']':'[','}':'{'}; opens=set(pairs.values())
    in_str=False; quote=''; esc=False; i=0
    while i<len(text):
        c=text[i]
        if in_str:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==quote: in_str=False
        else:
            if c in ('"',"'"): in_str=True; quote=c
            elif c=='#':
                j=text.find('\n',i)
                if j<0: break
                i=j
            elif c in opens: stack.append(c)
            elif c in pairs:
                if not stack or stack[-1]!=pairs[c]:
                    errors.append(f'{name}: delimiter mismatch near offset {i}')
                    return
                stack.pop()
        i+=1
    if stack: errors.append(f'{name}: unclosed delimiters {stack[-8:]}')
for gd in (ROOT/'scripts').glob('*.gd'): scan(gd.read_text(), gd.name)

for name, passed, detail in checks:
    print(('PASS' if passed else 'FAIL'), '-', name, detail)
print('\nRESULT:', 'PASS' if not errors else 'FAIL')
if errors:
    print('\n'.join(errors)); sys.exit(1)
