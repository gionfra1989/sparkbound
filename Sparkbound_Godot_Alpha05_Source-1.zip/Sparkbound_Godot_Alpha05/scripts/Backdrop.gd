class_name SparkBackdrop
extends Control

var mode := "title"
var time := 0.0
var sky_data: Dictionary = {}
var sky_restored := false
var erase_amount := 0.0

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    queue_redraw()

func _process(delta: float) -> void:
    time += delta
    queue_redraw()

func _draw() -> void:
    match mode:
        "title": _draw_title()
        "intro": _draw_intro()
        _: _draw_world_sky()

func _draw_title() -> void:
    var s := size
    draw_rect(Rect2(Vector2.ZERO, s), Color("#f8f4e9"), true)
    draw_rect(Rect2(0, 0, s.x, s.y * .58), Color("#dcecef"), true)
    _soft_hills(s.y * .53, Color("#c4d0c4"), Color("#aabaaa"))
    var road := PackedVector2Array([
        Vector2(s.x * .50, s.y * .49), Vector2(s.x * .44, s.y * .64),
        Vector2(s.x * .57, s.y * .79), Vector2(s.x * .48, s.y * 1.04)
    ])
    draw_polyline(road, Color("#eadfbe"), 92, true)

    # Simple hero silhouette and Luma make it immediately read as an adventure.
    var hero := Vector2(s.x * .55, s.y * .72)
    draw_circle(hero + Vector2(0, -29), 22, Color("#7ba0df"))
    draw_rect(Rect2(hero + Vector2(-20, -8), Vector2(40, 50)), Color("#5579c4"), true)
    draw_circle(hero + Vector2(0, 5), 7, Color("#ffd65c"))

    var luma := Vector2(s.x * .68, s.y * .53 + sin(time * 2.4) * 8)
    draw_circle(luma, 21, Color(1, .84, .25, .16))
    draw_circle(luma, 8, Color("#ffd65c"))

    var v := Vector2(s.x * .23, s.y * .42)
    draw_circle(v + Vector2(0, -38), 23, Color("#242435"))
    draw_colored_polygon(PackedVector2Array([
        v + Vector2(-32, -16), v + Vector2(32, -16),
        v + Vector2(43, 66), v + Vector2(-43, 66)
    ]), Color("#302c43"))
    draw_arc(v + Vector2(0, -38), 33, PI, TAU, 22, Color("#9870b1"), 6)

func _draw_intro() -> void:
    var s := size
    draw_rect(Rect2(Vector2.ZERO, s), Color("#f4eee2"), true)
    var live_w := lerp(s.x * .84, s.x * .25, clamp(erase_amount, 0.0, 1.0))
    draw_rect(Rect2(0, 0, live_w, s.y), Color("#dcebdc"), true)
    draw_circle(Vector2(s.x * .22, s.y * .33), 72, Color("#7bcf8c"))
    draw_rect(Rect2(s.x * .07, s.y * .60, s.x * .35, s.y * .17), Color("#9dcea6"), true)

    # First Scribble.
    var scribble := Vector2(s.x * .48, s.y * .42)
    for i in range(7):
        var r := 26.0 + i * 10.0
        draw_arc(scribble, r, time * .22 + i * .78, time * .22 + i * .78 + PI * 1.45, 28, Color(.13, .12, .18, .72), 5)

    # Veyr and the Eraser wave.
    var v := Vector2(s.x * .80, s.y * .54)
    draw_circle(v + Vector2(0, -62), 28, Color("#252536"))
    draw_rect(Rect2(v + Vector2(-39, -33), Vector2(78, 122)), Color("#312d43"), true)
    draw_arc(v + Vector2(0, -62), 40, PI, TAU, 22, Color("#9c72b9"), 7)
    if erase_amount > .05:
        draw_colored_polygon(PackedVector2Array([
            v + Vector2(-12, -10), Vector2(live_w, 0),
            Vector2(live_w, s.y), v + Vector2(-12, 50)
        ]), Color(1, 1, .98, .68))

func _draw_world_sky() -> void:
    var s := size
    # IMPORTANT: sky only occupies the upper half of the viewport. It can never
    # appear at road height.
    var sky_h := s.y * .55
    draw_rect(Rect2(0, 0, s.x, sky_h), Color("#eeeeeb") if not sky_restored else Color("#a7ddf1"), true)
    draw_rect(Rect2(0, sky_h, s.x, s.y - sky_h), Color(1, 1, 1, 0), true)

    _soft_hills(sky_h + 55, Color("#d7d8d3") if not sky_restored else Color("#bed0b9"), Color("#c5c6c2") if not sky_restored else Color("#a6bda3"))

    # Player sky strokes remain recognisable and drift very slightly like a real
    # sky while staying inside the top 50% of the screen.
    if sky_restored and not sky_data.is_empty():
        for st in sky_data.get("strokes", []):
            var pts: Array = st.get("points", [])
            if pts.size() < 2: continue
            var poly := PackedVector2Array()
            for p: Vector2 in pts:
                poly.append(Vector2(
                    p.x * s.x,
                    18 + p.y * (sky_h - 70) + sin(time * .30 + p.x * 5.0) * 3.0
                ))
            var c := Color.from_string(str(st.get("color", "#4a90e2")), Color("#4a90e2"))
            c.a = .38
            draw_polyline(poly, c, clamp(float(st.get("width", 8)) * .40, 2.0, 9.0), true)

func _soft_hills(base_y: float, c1: Color, c2: Color) -> void:
    # Smooth, repeating silhouettes instead of sharp random mountain triangles.
    # This keeps the world visually calm and makes the road the obvious route.
    var s := size
    var back := PackedVector2Array()
    var front := PackedVector2Array()
    var steps := 32
    for i in range(steps + 1):
        var x := s.x * float(i) / float(steps)
        var y_back := base_y - 54.0 - sin(float(i) * .72) * 28.0 - sin(float(i) * .29) * 17.0
        var y_front := base_y - 20.0 - sin(float(i) * .58 + .8) * 24.0
        back.append(Vector2(x,y_back))
        front.append(Vector2(x,y_front))
    back.append(Vector2(s.x,base_y+190));back.append(Vector2(0,base_y+190))
    front.append(Vector2(s.x,base_y+195));front.append(Vector2(0,base_y+195))
    var cc := c2;cc.a=.42
    draw_colored_polygon(back,cc)
    draw_colored_polygon(front,c1)
