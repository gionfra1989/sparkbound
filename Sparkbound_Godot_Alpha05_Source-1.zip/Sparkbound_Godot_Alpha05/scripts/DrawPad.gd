class_name DrawPad
extends Control

signal finished(kind:String,data:Dictionary)
signal cancelled

var kind := "free"
var age := 8
var prompt := "CREATE"
var hint := "Draw what the world needs."
var strokes:Array = []
var current:Array[Vector2] = []
var current_color := Color("#30303a")
var current_width := 8.0
var current_tool := "pencil"
var drawing := false
var active_pointer := -999
var canvas := Rect2()
var ui_scale := 1.0
var left_anchor := Vector2.ZERO
var right_anchor := Vector2.ZERO
var colors:Array = []

var title:Label
var helper:Label
var done:Button
var back:Button
var undo:Button
var clear:Button
var pencil:Button
var marker:Button
var crayon:Button
var draw_surface:Control
var color_buttons:Array[Button] = []

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    position = Vector2.ZERO
    size = get_viewport_rect().size
    mouse_filter = Control.MOUSE_FILTER_PASS
    set_process_input(true)
    _build()
    get_viewport().size_changed.connect(_layout)
    _layout()
    queue_redraw()

func setup(p_kind:String, prompt_text:String, hint_text:String, p_age:int, p_colors:Array) -> void:
    kind = p_kind
    prompt = prompt_text
    hint = hint_text
    age = p_age
    colors = p_colors.duplicate()
    drawing = false
    active_pointer = -999
    current.clear()
    strokes.clear()
    if title: title.text = prompt
    if helper: helper.text = hint
    _palette()
    _layout()
    queue_redraw()

func _build() -> void:
    # A dedicated touch surface owns drawing input. This is intentionally not
    # viewport-global: every drawing mission gets a fresh surface, preventing
    # Android touches from being swallowed by UI left over from a previous task.
    draw_surface = Control.new()
    draw_surface.mouse_filter = Control.MOUSE_FILTER_STOP
    draw_surface.focus_mode = Control.FOCUS_NONE
    draw_surface.gui_input.connect(_surface_input)
    add_child(draw_surface)

    title = Label.new()
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 30)
    title.add_theme_color_override("font_color", Color("#27283b"))
    add_child(title)

    helper = Label.new()
    helper.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    helper.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    helper.add_theme_font_size_override("font_size", 17)
    helper.add_theme_color_override("font_color", Color("#5c6075"))
    add_child(helper)

    back = _btn("BACK")
    back.pressed.connect(_cancel)
    add_child(back)

    undo = _btn("UNDO")
    undo.pressed.connect(func():
        if not strokes.is_empty(): strokes.pop_back()
        current.clear()
        drawing = false
        active_pointer = -999
        queue_redraw()
    )
    add_child(undo)

    clear = _btn("CLEAR")
    clear.pressed.connect(func():
        strokes.clear()
        current.clear()
        drawing = false
        active_pointer = -999
        helper.text = hint
        queue_redraw()
    )
    add_child(clear)

    done = _btn("MAKE IT REAL ✦")
    done.pressed.connect(_finish)
    add_child(done)

    pencil = _btn("PENCIL")
    marker = _btn("MARKER")
    crayon = _btn("CRAYON")
    pencil.pressed.connect(func(): current_tool = "pencil"; current_width = 6.0; _refresh_tool_labels())
    marker.pressed.connect(func(): current_tool = "marker"; current_width = 13.0; _refresh_tool_labels())
    crayon.pressed.connect(func(): current_tool = "crayon"; current_width = 10.0; _refresh_tool_labels())
    add_child(pencil)
    add_child(marker)
    add_child(crayon)
    _refresh_tool_labels()

func _palette() -> void:
    for b in color_buttons:
        if is_instance_valid(b): b.queue_free()
    color_buttons.clear()
    var use_colors:Array = colors if not colors.is_empty() else [Color("#30303a"), Color("#4aa96c"), Color("#4a90e2"), Color("#f6c344"), Color("#ef6b6b")]
    for c_value in use_colors:
        var c:Color = c_value
        var b := Button.new()
        b.focus_mode = Control.FOCUS_NONE
        b.custom_minimum_size = Vector2(42, 42)
        var sb := StyleBoxFlat.new()
        sb.bg_color = c
        sb.corner_radius_top_left = 22
        sb.corner_radius_top_right = 22
        sb.corner_radius_bottom_left = 22
        sb.corner_radius_bottom_right = 22
        sb.border_width_left = 2
        sb.border_width_right = 2
        sb.border_width_top = 2
        sb.border_width_bottom = 2
        sb.border_color = Color("#2e3042")
        b.add_theme_stylebox_override("normal", sb)
        b.add_theme_stylebox_override("pressed", sb)
        b.pressed.connect(_choose_color.bind(c))
        add_child(b)
        color_buttons.append(b)
    if not use_colors.is_empty(): current_color = use_colors[0]

func _choose_color(c:Color) -> void:
    current_color = c

func _layout() -> void:
    var s := get_viewport_rect().size
    position = Vector2.ZERO
    size = s
    ui_scale = clamp(min(s.x / 1280.0, s.y / 720.0), .72, 1.35)
    var m := 26.0 * ui_scale

    title.position = Vector2(m, 18 * ui_scale)
    title.size = Vector2(s.x - m * 2.0, 42 * ui_scale)
    helper.position = Vector2(150 * ui_scale, 60 * ui_scale)
    helper.size = Vector2(s.x - 300 * ui_scale, 44 * ui_scale)
    back.position = Vector2(m, 24 * ui_scale)
    back.size = Vector2(105 * ui_scale, 44 * ui_scale)

    canvas = Rect2(m, 118 * ui_scale, s.x - m * 2.0, s.y - 260 * ui_scale)
    left_anchor = Vector2(canvas.position.x + 42 * ui_scale, canvas.get_center().y)
    right_anchor = Vector2(canvas.end.x - 42 * ui_scale, canvas.get_center().y)
    draw_surface.position = canvas.position
    draw_surface.size = canvas.size
    draw_surface.move_to_front()

    # Buttons stay outside the drawing surface and are moved to the front after
    # the surface, so tapping tools can never accidentally start a stroke.
    undo.position = Vector2(m, s.y - 62 * ui_scale)
    undo.size = Vector2(86 * ui_scale, 46 * ui_scale)
    clear.position = Vector2(m + 94 * ui_scale, s.y - 62 * ui_scale)
    clear.size = Vector2(86 * ui_scale, 46 * ui_scale)
    done.position = Vector2(s.x - m - 240 * ui_scale, s.y - 62 * ui_scale)
    done.size = Vector2(240 * ui_scale, 46 * ui_scale)

    var tx := m + 195 * ui_scale
    var ty := s.y - 62 * ui_scale
    pencil.position = Vector2(tx, ty)
    pencil.size = Vector2(100 * ui_scale, 46 * ui_scale)
    marker.position = Vector2(tx + 108 * ui_scale, ty)
    marker.size = Vector2(100 * ui_scale, 46 * ui_scale)
    crayon.position = Vector2(tx + 216 * ui_scale, ty)
    crayon.size = Vector2(100 * ui_scale, 46 * ui_scale)

    # No tool is removed for younger players. Simplicity comes from guidance,
    # not from deleting controls the player already saw elsewhere.
    pencil.visible = true
    marker.visible = true
    crayon.visible = true
    undo.visible = true

    var total := color_buttons.size() * 48.0 * ui_scale
    var x := max(m, s.x * .5 - total * .5)
    var y := canvas.end.y + 12 * ui_scale
    for b in color_buttons:
        b.position = Vector2(x, y)
        b.size = Vector2(42 * ui_scale, 42 * ui_scale)
        x += 48 * ui_scale

    for c in [title, helper, back, undo, clear, pencil, marker, crayon, done]:
        c.move_to_front()
    for b in color_buttons: b.move_to_front()
    queue_redraw()

func _input(event:InputEvent) -> void:
    # Android path: handle raw touch coordinates before the GUI stage. We only
    # consume events that start on the paper (or belong to the active stroke),
    # so tool buttons remain normal Godot Buttons.
    if event is InputEventScreenTouch:
        if event.pressed:
            if canvas.has_point(event.position) and not drawing:
                _handle_pointer(event.position,event.index,true,false,false)
                get_viewport().set_input_as_handled()
        elif drawing and event.index==active_pointer:
            _handle_pointer(event.position,event.index,false,true,false)
            get_viewport().set_input_as_handled()
    elif event is InputEventScreenDrag and drawing and event.index==active_pointer:
        _handle_pointer(event.position,event.index,false,false,true)
        get_viewport().set_input_as_handled()

func _surface_input(event:InputEvent) -> void:
    # Desktop/testing path. In Control GUI input, event.position is local to the
    # drawing surface, so translate it back to DrawPad coordinates.
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        var p := canvas.position + event.position
        _handle_pointer(p,-99,event.pressed,not event.pressed,false)
        draw_surface.accept_event()
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        if drawing and active_pointer==-99:
            var p := canvas.position + event.position
            _handle_pointer(p,-99,false,false,true)
            draw_surface.accept_event()

func _handle_pointer(p:Vector2,pointer_id:int,press:bool,release:bool,motion:bool) -> void:
    if press and not drawing:
        drawing = true
        active_pointer = pointer_id
        current = [_clamp_to_canvas(p)]
        queue_redraw()
        return

    if motion and drawing and pointer_id == active_pointer:
        var cp := _clamp_to_canvas(p)
        if current.is_empty() or current[-1].distance_to(cp) > 2.5 * ui_scale:
            current.append(cp)
        queue_redraw()
        return

    if release and drawing and pointer_id == active_pointer:
        var cp := _clamp_to_canvas(p)
        if current.is_empty(): current.append(cp)
        if current.size() == 1:
            current.append(current[0] + Vector2(1.5, 1.5) * ui_scale)
        elif current[-1].distance_to(cp) > 1.0 * ui_scale:
            current.append(cp)
        strokes.append({"points": current.duplicate(), "color": current_color, "width": current_width * ui_scale, "tool": current_tool})
        drawing = false
        active_pointer = -999
        current.clear()
        helper.text = hint
        queue_redraw()

func _clamp_to_canvas(p:Vector2) -> Vector2:
    return Vector2(clamp(p.x, canvas.position.x, canvas.end.x), clamp(p.y, canvas.position.y, canvas.end.y))

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color("#eee8da"), true)
    draw_rect(canvas.grow(7 * ui_scale), Color("#c9c2b4"), true)
    draw_rect(canvas, Color("#fffdf7"), true)
    for yy in range(int(canvas.position.y + 35), int(canvas.end.y), 40):
        draw_line(Vector2(canvas.position.x + 12, yy), Vector2(canvas.end.x - 12, yy), Color(.87, .85, .79, .25), 1)

    if kind == "bridge":
        draw_circle(left_anchor, 25 * ui_scale, Color("#ddd5c3"))
        draw_circle(right_anchor, 25 * ui_scale, Color("#ddd5c3"))
        draw_string(ThemeDB.fallback_font, left_anchor + Vector2(-40, -34) * ui_scale, "LEFT BANK", HORIZONTAL_ALIGNMENT_LEFT, -1, 13 * ui_scale, Color("#6c6871"))
        draw_string(ThemeDB.fallback_font, right_anchor + Vector2(-42, -34) * ui_scale, "RIGHT BANK", HORIZONTAL_ALIGNMENT_LEFT, -1, 13 * ui_scale, Color("#6c6871"))
        if age <= 5:
            var segments := 10
            for i in range(segments):
                if i % 2 == 0:
                    var a := left_anchor.lerp(right_anchor, float(i) / segments)
                    var b := left_anchor.lerp(right_anchor, float(i + 1) / segments)
                    draw_line(a, b, Color(.55, .53, .50, .20), 5 * ui_scale, true)

    for st in strokes: _stroke(st)
    if current.size() > 1:
        _stroke({"points": current, "color": current_color, "width": current_width * ui_scale, "tool": current_tool})

func _stroke(st:Dictionary) -> void:
    var pts:Array = st.get("points", [])
    if pts.size() < 2: return
    var pk := _smooth_points(pts)
    var c:Color = st.get("color", Color.BLACK)
    var w := float(st.get("width", 8))
    var tool := str(st.get("tool", "pencil"))
    if tool == "marker": c.a = .72
    draw_polyline(pk, c, w, true)
    if tool == "crayon":
        var off := PackedVector2Array()
        for p in pk: off.append(p + Vector2(1.6, -1.1) * ui_scale)
        var c2 := c
        c2.a = .25
        draw_polyline(off, c2, max(2.0, w * .35), true)

func _smooth_points(pts:Array) -> PackedVector2Array:
    var out := PackedVector2Array()
    if pts.size() < 3:
        for p in pts: out.append(p)
        return out
    out.append(pts[0])
    for i in range(1, pts.size() - 1):
        var a:Vector2 = pts[i - 1]
        var b:Vector2 = pts[i]
        var c:Vector2 = pts[i + 1]
        out.append(a.lerp(b, .55))
        out.append((a + b * 2.0 + c) / 4.0)
    out.append(pts[-1])
    return out

func _cancel() -> void:
    drawing = false
    active_pointer = -999
    set_process_input(false)
    if is_instance_valid(draw_surface): draw_surface.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cancelled.emit()
    queue_free()

func _finish() -> void:
    if drawing:
        helper.text = "Lift your finger, then tap MAKE IT REAL."
        return
    if strokes.is_empty():
        helper.text = "Draw something first — then it can exist in the world."
        return
    var data := _normalized()
    if kind == "bridge" and not bool(data.get("bridge_ok", false)):
        helper.text = "Touch the LEFT BANK, draw one path, and finish at the RIGHT BANK."
        return
    # Stop accepting input before the callback changes screens. This prevents
    # the finished drawing panel from stealing the first tap on the next screen.
    drawing = false
    active_pointer = -999
    set_process_input(false)
    if is_instance_valid(draw_surface): draw_surface.mouse_filter = Control.MOUSE_FILTER_IGNORE
    finished.emit(kind, data)
    queue_free()

func _normalized() -> Dictionary:
    var out:Array = []
    var all:Array[Vector2] = []
    for st in strokes:
        var npts:Array = []
        for p:Vector2 in st.points:
            var n := Vector2((p.x - canvas.position.x) / canvas.size.x, (p.y - canvas.position.y) / canvas.size.y)
            n.x = clamp(n.x, 0.0, 1.0)
            n.y = clamp(n.y, 0.0, 1.0)
            npts.append(n)
            all.append(n)
        var c:Color = st.color
        out.append({"points": npts, "color": c.to_html(true), "width": float(st.width) / max(ui_scale, .01), "tool": st.tool})

    var minp := Vector2(1, 1)
    var maxp := Vector2.ZERO
    for p in all:
        minp.x = min(minp.x, p.x)
        minp.y = min(minp.y, p.y)
        maxp.x = max(maxp.x, p.x)
        maxp.y = max(maxp.y, p.y)

    var bridge_ok := true
    if kind == "bridge":
        bridge_ok = false
        for st in out:
            var pts:Array = st.points
            if pts.size() > 1:
                var a:Vector2 = pts.front()
                var b:Vector2 = pts.back()
                if min(a.x, b.x) < .10 and max(a.x, b.x) > .90:
                    bridge_ok = true
                    break
    return {"strokes": out, "bounds": [minp.x, minp.y, maxp.x, maxp.y], "bridge_ok": bridge_ok, "kind": kind}

func _refresh_tool_labels() -> void:
    if not pencil: return
    pencil.text = "✓ PENCIL" if current_tool == "pencil" else "PENCIL"
    marker.text = "✓ MARKER" if current_tool == "marker" else "MARKER"
    crayon.text = "✓ CRAYON" if current_tool == "crayon" else "CRAYON"

func _btn(text:String) -> Button:
    var b := Button.new()
    b.text = text
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", 14)
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color("#fffdf6")
    sb.corner_radius_top_left = 15
    sb.corner_radius_top_right = 15
    sb.corner_radius_bottom_left = 15
    sb.corner_radius_bottom_right = 15
    sb.border_width_left = 2
    sb.border_width_right = 2
    sb.border_width_top = 2
    sb.border_width_bottom = 2
    sb.border_color = Color("#d2ccbe")
    b.add_theme_stylebox_override("normal", sb)
    return b
