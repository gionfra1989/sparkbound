extends Node

const PlayerScript=preload("res://scripts/Player.gd")
const WorldScript=preload("res://scripts/World.gd")
const DrawPadScript=preload("res://scripts/DrawPad.gd")
const TouchUIScript=preload("res://scripts/TouchUI.gd")
const NPCScript=preload("res://scripts/NPC.gd")
const EnemyScript=preload("res://scripts/Enemy.gd")
const CompanionScript=preload("res://scripts/Companion.gd")
const BackdropScript=preload("res://scripts/Backdrop.gd")
const SFX_SPARK=preload("res://audio/spark.wav")
const SFX_HIT=preload("res://audio/hit.wav")
const SFX_SPLASH=preload("res://audio/splash.wav")
const SFX_LUMA=preload("res://audio/luma.wav")
const SFX_CREATE=preload("res://audio/create.wav")

var state:="title"
var age:=8
var stage:=0
var player:SparkPlayer
var world:SparkWorld
var controls:TouchUI
var camera:Camera2D
var world_root:Node2D
var ui_layer:CanvasLayer
var overlay_layer:CanvasLayer
var backdrop_layer:CanvasLayer
var sky_layer:CanvasLayer
var backdrop:SparkBackdrop
var hero_data:Dictionary={}
var hero_preset:=0
var tree_data:Dictionary={}
var sky_data:Dictionary={}
var bridge_data:Dictionary={}
var sword_data:Dictionary={}
var dog_data:Dictionary={}
var miro:SparkNPC
var pip:SparkNPC
var companion:SketchCompanion
var enemies:Array=[]
var hud:Control
var health_label:Label
var stage_label:Label
var objective_label:Label
var toast_label:Label
var dialogue_panel:Panel
var dialogue_name:Label
var dialogue_text:Label
var dialogue_button:Button
var dialogue_lines:Array=[]
var dialogue_index:=0
var dialogue_after:Callable
var dialogue_timer:=0.0
var intro_root:Control
var intro_text:Label
var intro_next:Button
var intro_index:=0
var menu_root:Control
var pause_root:Control
var stage_banner_timer:=0.0
var water_cooldown:=0.0
var secret_found:=false
var tree_rewarded:=false

func _ready()->void:
    _build_layers();_show_title()

func _build_layers()->void:
    backdrop_layer=CanvasLayer.new();backdrop_layer.layer=-20;add_child(backdrop_layer)
    sky_layer=CanvasLayer.new();sky_layer.layer=-10;add_child(sky_layer)
    ui_layer=CanvasLayer.new();ui_layer.layer=20;add_child(ui_layer)
    overlay_layer=CanvasLayer.new();overlay_layer.layer=40;add_child(overlay_layer)

func _process(delta:float)->void:
    water_cooldown=max(0.0,water_cooldown-delta)
    stage_banner_timer=max(0.0,stage_banner_timer-delta)
    if is_instance_valid(stage_label):stage_label.modulate.a=clamp(stage_banner_timer,0.0,1.0)
    if is_instance_valid(objective_label):objective_label.modulate.a=clamp(stage_banner_timer+1.4,0.0,1.0)
    if state=="dialogue" and age<=5:
        dialogue_timer-=delta
        if dialogue_timer<=0:_advance_dialogue()
    if state=="playing" and is_instance_valid(player):
        player.set_external_input(controls.move_vector if is_instance_valid(controls) else Vector2.ZERO)
        _update_story()
        _update_near_action()
        _update_hud()
        if world.is_water(player.global_position):
            if world.is_bridge_safe(player.global_position):
                # The player physically follows the child's drawn line instead of
                # walking on an invisible rectangular platform. Keep X controlled by
                # the player and softly pull Y onto the bridge curve.
                var bridge_point:=world.bridge_closest_point(player.global_position)
                player.global_position.y=lerp(player.global_position.y,bridge_point.y,.42)
            elif water_cooldown<=0:
                water_cooldown=1.0
                _play_sfx(SFX_SPLASH,.8)
                _toast("SPLASH! Draw one clear path all the way across.")
                player.respawn()
    elif is_instance_valid(player):player.set_external_input(Vector2.ZERO)

func _unhandled_input(event:InputEvent)->void:
    if state!="playing" or not is_instance_valid(player):return
    if event.is_action_pressed("jump"):player.do_jump()
    if event.is_action_pressed("attack"):player.do_attack()
    if event.is_action_pressed("interact"):_interact()

# -----------------------------------------------------------------------------
# TITLE / SETUP
# -----------------------------------------------------------------------------
func _retire(node:Node)->void:
    if not is_instance_valid(node): return
    var parent:=node.get_parent()
    if is_instance_valid(parent): parent.remove_child(node)
    node.queue_free()

func _clear_layers()->void:
    # Remove old UI from the tree immediately before queue_free. This prevents a
    # transparent Control from a previous screen intercepting the very next tap.
    for layer in [ui_layer,overlay_layer,backdrop_layer,sky_layer]:
        for c in layer.get_children(): _retire(c)

func _show_title()->void:
    state="title"
    _clear_game()
    _clear_layers()
    backdrop=BackdropScript.new()
    backdrop.mode="title"
    backdrop_layer.add_child(backdrop)
    menu_root=Control.new()
    menu_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_layer.add_child(menu_root)

    var title:=Label.new()
    title.text="SPARKBOUND"
    title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size",62)
    title.add_theme_color_override("font_color",Color("#262942"))
    title.position=Vector2(0,58)
    title.size=Vector2(1280,78)
    menu_root.add_child(title)

    var sub:=Label.new()
    sub.text="DRAW IT. RESTORE IT. LIVE THE ADVENTURE."
    sub.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    sub.add_theme_font_size_override("font_size",18)
    sub.add_theme_color_override("font_color",Color("#5b6078"))
    sub.position=Vector2(0,132)
    sub.size=Vector2(1280,34)
    menu_root.add_child(sub)

    var story:=_game_button("NEW ADVENTURE  ✦",Vector2(420,282),Vector2(440,68),Color("#f2c85c"))
    story.pressed.connect(_show_age)
    menu_root.add_child(story)

    var maker:=_game_button("MAKER WORLD",Vector2(245,385),Vector2(360,60),Color("#8ed1a9"))
    maker.pressed.connect(func():_show_menu_feature("maker"))
    menu_root.add_child(maker)

    var hero:=_game_button("HERO STUDIO",Vector2(675,385),Vector2(360,60),Color("#b493dc"))
    hero.pressed.connect(func():_show_menu_feature("hero"))
    menu_root.add_child(hero)

    var book:=_game_button("STORY BOOK",Vector2(245,470),Vector2(360,60),Color("#77b9e1"))
    book.pressed.connect(func():_show_menu_feature("book"))
    menu_root.add_child(book)

    var community:=_game_button("COMMUNITY WORLDS",Vector2(675,470),Vector2(360,60),Color("#ee9a70"))
    community.pressed.connect(func():_show_menu_feature("community"))
    menu_root.add_child(community)

    var alpha:=Label.new()
    alpha.text="GODOT ALPHA 0.5 · THE FIRST ROAD"
    alpha.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    alpha.position=Vector2(0,650)
    alpha.size=Vector2(1280,28)
    alpha.add_theme_font_size_override("font_size",14)
    alpha.add_theme_color_override("font_color",Color("#777b8c"))
    menu_root.add_child(alpha)

func _show_menu_feature(feature:String)->void:
    state="menu_feature"
    if is_instance_valid(menu_root): _retire(menu_root)
    var root:=Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui_layer.add_child(root)
    menu_root=root

    var card:=Panel.new()
    card.position=Vector2(265,120)
    card.size=Vector2(750,480)
    card.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")))
    root.add_child(card)

    var title_text:=""
    var desc:=""
    var action_text:=""
    match feature:
        "maker":
            title_text="MAKER WORLD"
            desc="A safe creative room for drawing pieces of a future world. In this alpha you can make one World Mark and keep it ready for the adventure system."
            action_text="DRAW A WORLD MARK"
        "hero":
            title_text="HERO STUDIO"
            desc="Create a hero with the same drawing system used in the adventure. The drawing is saved for this session and can be reused while testing."
            action_text="DRAW A HERO"
        "book":
            title_text="STORY BOOK"
            desc="ACT I · THE WHITE VALE\n\nVeyr used the Great Eraser to trap the First Scribble. The prison worked — but colour and memory vanished too. Luma has found a new Maker, and every restored drawing is waking something under the paper."
        "community":
            title_text="COMMUNITY WORLDS"
            desc="Future shared Maker adventures live here. The alpha keeps this offline: no chat, no accounts and no child data leaves the device."

    var t:=Label.new()
    t.text=title_text
    t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    t.add_theme_font_size_override("font_size",34)
    t.position=Vector2(30,38)
    t.size=Vector2(690,48)
    card.add_child(t)

    var info:=Label.new()
    info.text=desc
    info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    info.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    info.vertical_alignment=VERTICAL_ALIGNMENT_CENTER
    info.add_theme_font_size_override("font_size",19)
    info.add_theme_color_override("font_color",Color("#4e5267"))
    info.position=Vector2(75,105)
    info.size=Vector2(600,205)
    card.add_child(info)

    if feature=="book":
        var chapter:=Label.new()
        chapter.text="1  THE FORGOTTEN GROVE   →   2  THE EMPTY SKY   →   3  THE OLD GATE"
        chapter.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
        chapter.add_theme_font_size_override("font_size",15)
        chapter.position=Vector2(40,315)
        chapter.size=Vector2(670,32)
        card.add_child(chapter)
    elif feature=="community":
        var badges:=Label.new()
        badges.text="NO OPEN CHAT   ·   NO VOICE   ·   PARENT-CONTROLLED SHARING"
        badges.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
        badges.add_theme_font_size_override("font_size",14)
        badges.position=Vector2(30,315)
        badges.size=Vector2(690,32)
        card.add_child(badges)
    else:
        var action:=_game_button(action_text,Vector2(205,305),Vector2(340,58),Color("#f2c85c"))
        if feature=="maker":
            action.pressed.connect(func():_open_menu_draw("world","DRAW A WORLD MARK","Anything is allowed. This is a creative sandbox test.",[Color("#30303a"),Color("#4aa96c"),Color("#4a90e2"),Color("#f6c344"),Color("#ef6b6b")],func(_d):_show_saved_feature("WORLD MARK SAVED","Your drawing worked. Maker World will grow around this system.")))
        else:
            action.pressed.connect(func():_open_menu_draw("hero","DRAW YOUR HERO","Any shape is allowed. The drawing remains yours.",[Color("#30303a"),Color("#4a90e2"),Color("#4aa96c"),Color("#f6c344"),Color("#ef6b6b"),Color("#9b6de3")],func(d):hero_data=d;_show_saved_feature("HERO SAVED","Your drawn hero is stored for this testing session.")))
        card.add_child(action)

    var back:=_game_button("BACK",Vector2(275,393),Vector2(200,52),Color("#ddd8cb"))
    back.pressed.connect(_show_title)
    card.add_child(back)

func _show_saved_feature(title_text:String,body:String)->void:
    _clear_layers()
    backdrop=BackdropScript.new();backdrop.mode="title";backdrop_layer.add_child(backdrop)
    var root:=Control.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui_layer.add_child(root);menu_root=root
    var card:=Panel.new();card.position=Vector2(345,205);card.size=Vector2(590,300);card.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")));root.add_child(card)
    var t:=Label.new();t.text=title_text;t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;t.add_theme_font_size_override("font_size",31);t.position=Vector2(30,45);t.size=Vector2(530,44);card.add_child(t)
    var info:=Label.new();info.text=body;info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;info.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;info.position=Vector2(65,110);info.size=Vector2(460,60);info.add_theme_font_size_override("font_size",18);card.add_child(info)
    var home:=_game_button("BACK TO HOME",Vector2(170,205),Vector2(250,54),Color("#f2c85c"));home.pressed.connect(_show_title);card.add_child(home)

func _open_menu_draw(kind:String,prompt:String,hint:String,palette:Array,done_cb:Callable)->void:
    state="drawing"
    if is_instance_valid(menu_root): _retire(menu_root)
    var d:=DrawPadScript.new()
    overlay_layer.add_child(d)
    d.setup(kind,prompt,hint,8,palette)
    d.cancelled.connect(_show_title)
    d.finished.connect(func(_kind,data):
        _play_sfx(SFX_CREATE,.55)
        if done_cb.is_valid(): done_cb.call(data)
    )

func _show_how()->void:
    _show_menu_feature("book")

func _show_age()->void:
    state="age"
    if is_instance_valid(menu_root):_retire(menu_root)
    var root:=Control.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui_layer.add_child(root)
    var card:=Panel.new();card.position=Vector2(330,135);card.size=Vector2(620,445);card.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")));root.add_child(card)
    var t:=Label.new();t.text="GROWN-UP SETUP";t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;t.add_theme_font_size_override("font_size",29);t.position=Vector2(20,32);t.size=Vector2(580,44);card.add_child(t)
    var info:=Label.new();info.text="Pick an age. Younger Makers are guided automatically. Older Makers explore, fight and solve harder challenges — with the same story.";info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;info.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;info.position=Vector2(60,86);info.size=Vector2(500,70);info.add_theme_font_size_override("font_size",16);card.add_child(info)
    var groups=[{"label":"4–5\nGUIDED","age":5,"c":"#8ed1a9"},{"label":"6–8\nEXPLORER","age":7,"c":"#77b9e1"},{"label":"9–10\nADVENTURER","age":9,"c":"#b58cdd"},{"label":"11–12\nHERO","age":12,"c":"#ee9a70"}]
    for i in groups.size():
        var g=groups[i]
        var b:=_game_button(g.label,Vector2(42+i*137,183),Vector2(120,110),Color(g.c))
        b.pressed.connect(_select_age.bind(int(g.age),root))
        card.add_child(b)
    var back:=_game_button("BACK",Vector2(210,345),Vector2(200,54),Color("#ddd8cb"));back.pressed.connect(func():root.queue_free();_show_title());card.add_child(back)

func _select_age(selected_age:int,root:Control)->void:
    age=selected_age
    if is_instance_valid(root): root.queue_free()
    _start_intro()

func _start_intro()->void:
    state="intro";intro_index=0
    if is_instance_valid(backdrop):backdrop.mode="intro";backdrop.erase_amount=.05
    intro_root=Control.new();intro_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui_layer.add_child(intro_root)
    intro_text=Label.new();intro_text.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;intro_text.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;intro_text.vertical_alignment=VERTICAL_ALIGNMENT_CENTER;intro_text.add_theme_font_size_override("font_size",25);intro_text.add_theme_color_override("font_color",Color("#27283b"));intro_text.position=Vector2(235,470);intro_text.size=Vector2(810,120);intro_root.add_child(intro_text)
    intro_next=_game_button("NEXT",Vector2(520,612),Vector2(240,58),Color("#f2c85c"));intro_next.pressed.connect(_intro_advance);intro_root.add_child(intro_next);_refresh_intro()

func _refresh_intro()->void:
    var slides=[
        "Before the Erasure, children called Makers could draw something new — and the world learned how to use it.",
        "Then one drawing learned to create without a Maker. THE FIRST SCRIBBLE began changing creatures, places... even memories.",
        "Veyr used the Great Eraser to imprison it. He succeeded — but the Eraser took the world's colour and memory with it.",
        "Now the White Vale is almost empty. One Spark named Luma has found a new Maker. And Veyr has already noticed."
    ]
    intro_text.text=slides[intro_index];backdrop.erase_amount=float(intro_index)/3.0;intro_next.text="CREATE YOUR HERO" if intro_index==3 else "NEXT"
func _intro_advance()->void:
    intro_index+=1
    if intro_index>=4:_show_hero_choice()
    else:_refresh_intro()

func _show_hero_choice()->void:
    state="hero_select"
    if is_instance_valid(intro_root):
        _retire(intro_root)
    backdrop.mode="title"
    var root:=Control.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);ui_layer.add_child(root)
    var card:=Panel.new();card.position=Vector2(285,105);card.size=Vector2(710,505);card.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")));root.add_child(card)
    var t:=Label.new();t.text="WHO WAKES THE WORLD?";t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;t.add_theme_font_size_override("font_size",29);t.position=Vector2(20,32);t.size=Vector2(670,44);card.add_child(t)
    var info:=Label.new();info.text="Choose a Maker hero or draw your own. Your drawing stays your hero for the whole adventure.";info.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;info.position=Vector2(40,83);info.size=Vector2(630,42);card.add_child(info)
    for i in range(3):
        var b:=_game_button(["SKY MAKER","WILD MAKER","FORGE MAKER"][i],Vector2(48+i*208,148),Vector2(185,118),[Color("#7eb6df"),Color("#82c69b"),Color("#e58c6b")][i])
        b.pressed.connect(_select_hero_preset.bind(i,root))
        card.add_child(b)
    var draw:=_game_button("✎ DRAW MY HERO",Vector2(180,306),Vector2(350,72),Color("#b493dc"));draw.pressed.connect(func():root.queue_free();_draw_hero());card.add_child(draw)
    var back:=_game_button("BACK",Vector2(255,407),Vector2(200,50),Color("#ddd8cb"));back.pressed.connect(func():root.queue_free();_start_intro());card.add_child(back)

func _select_hero_preset(index:int,root:Control)->void:
    hero_preset=index
    hero_data={}
    if is_instance_valid(root): root.queue_free()
    _begin_game()

func _draw_hero()->void:
    _open_draw("hero","DRAW YOUR HERO","Any shape is allowed. Sparkbound will make it move.",[Color("#30303a"),Color("#4a90e2"),Color("#4aa96c"),Color("#f6c344"),Color("#ef6b6b"),Color("#9b6de3")],func(d):hero_data=d;_begin_game())

# -----------------------------------------------------------------------------
# GAMEPLAY
# -----------------------------------------------------------------------------
func _begin_game()->void:
    _clear_layers();state="playing";stage=0
    backdrop=BackdropScript.new();backdrop.mode="world";sky_layer.add_child(backdrop)
    world_root=Node2D.new();add_child(world_root)
    world=WorldScript.new();world_root.add_child(world)
    player=PlayerScript.new();player.position=Vector2(210,1030);player.configure(age,hero_data,hero_preset);world_root.add_child(player);player.set_checkpoint(player.position)
    player.fell.connect(_on_player_fell)
    player.attacked.connect(func():_play_sfx(SFX_HIT,.72))
    camera=Camera2D.new();camera.position_smoothing_enabled=true;camera.position_smoothing_speed=5.0;camera.limit_left=0;camera.limit_top=0;camera.limit_right=int(world.world_size.x);camera.limit_bottom=int(world.world_size.y);player.add_child(camera);camera.make_current()
    _spawn_npcs();_build_hud();_build_controls();_spawn_luma()
    _banner("ACT I · THE WHITE VALE","Follow Luma. Find out what the world forgot.")
    _dialogue(["Maker... can you hear me?","I'm Luma. Veyr erased this place.","Follow the pale road. We can draw the world back together."],"LUMA",func():_set_stage(0))


func _on_player_fell()->void:
    _toast("Luma pulled you back to the last safe place.")
    if stage==6:
        call_deferred("_bridge_retry")

func _bridge_retry()->void:
    if state!="playing" or stage!=6:return
    _dialogue(["That bridge didn't reach safely. Try again — make one clear path from LEFT BANK to RIGHT BANK."],"LUMA",_ask_bridge)

func _spawn_luma()->void:
    var l:=preload("res://scripts/Luma.gd").new();world_root.add_child(l);l.global_position=player.global_position+Vector2(45,-55)
func _spawn_npcs()->void:
    miro=NPCScript.new();miro.position=Vector2(610,805);miro.setup("MIRO","maker",Color("#e4a45d"));miro.interacted.connect(_npc_interact);world_root.add_child(miro)
    pip=NPCScript.new();pip.position=Vector2(1130,760);pip.setup("PIP","child",Color("#77b9e1"));pip.interacted.connect(_npc_interact);world_root.add_child(pip)

func _build_hud()->void:
    hud=Control.new();hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);hud.mouse_filter=Control.MOUSE_FILTER_IGNORE;ui_layer.add_child(hud)
    health_label=Label.new();health_label.position=Vector2(92,24);health_label.size=Vector2(260,34);health_label.add_theme_font_size_override("font_size",20);health_label.add_theme_color_override("font_color",Color("#313347"));hud.add_child(health_label)
    stage_label=Label.new();stage_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;stage_label.position=Vector2(300,24);stage_label.size=Vector2(680,38);stage_label.add_theme_font_size_override("font_size",27);stage_label.add_theme_color_override("font_color",Color("#2d3047"));hud.add_child(stage_label)
    objective_label=Label.new();objective_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;objective_label.position=Vector2(290,62);objective_label.size=Vector2(700,32);objective_label.add_theme_font_size_override("font_size",16);objective_label.add_theme_color_override("font_color",Color("#5e6274"));hud.add_child(objective_label)
    toast_label=Label.new();toast_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;toast_label.position=Vector2(280,610);toast_label.size=Vector2(720,46);toast_label.add_theme_font_size_override("font_size",18);toast_label.add_theme_color_override("font_color",Color("#34364b"));hud.add_child(toast_label)
func _build_controls()->void:
    controls=TouchUIScript.new()
    controls.configure(age)
    controls.jump_pressed.connect(func():
        if state=="playing":
            player.do_jump()
    )
    controls.attack_pressed.connect(func():
        if state=="playing":
            player.do_attack()
    )
    controls.interact_pressed.connect(_interact)
    controls.back_pressed.connect(_pause)
    ui_layer.add_child(controls)

func _set_stage(s:int)->void:
    stage=s
    match stage:
        0:
            _banner("THE FORGOTTEN GROVE","Reach Miro at the end of the road.")
            if age<=5:player.guide_to(Vector2(600,820))
        1:
            _banner("THE FIRST MEMORY","Draw what you think a tree should be.")
        2:
            _banner("MEMORY HILL","Follow the road to Pip.")
            player.set_checkpoint(Vector2(720,900))
            if age<=5:
                player.guide_to(Vector2(1120,780))
        3:
            _banner("THE EMPTY SKY","Show the world what belongs above us.")
        4:
            _banner("THE ERASED RIVER","Follow the road to the river.")
            player.set_checkpoint(Vector2(1210,830))
            if age<=5:
                player.guide_to(Vector2(1325,820))
        5:_banner("NO ROAD REMAINS","Draw a bridge from one bank to the other.")
        6:
            _banner("TEST YOUR CREATION","Cross using the bridge you drew.")
            player.set_checkpoint(Vector2(1390,830))
            if age<=5:player.guide_to(Vector2(1740,830))
        7:_banner("SOMETHING IS COMING","Create a weapon you would trust.")
        8:_banner("THE BLANKLINGS","Protect the road.")
        9:_banner("A FRIEND IN THE WHITE","Draw a companion to help you track a lost memory.")
        10:
            _banner("FOLLOW THE PAWPRINTS","Your companion knows where a memory is hidden.")
            if is_instance_valid(companion):companion.sniff(Vector2(2420,545))
            if age<=5:player.guide_to(Vector2(2420,545))
        11:
            _banner("THE OLD GATE","Take the recovered memory to the gate.")
            player.set_checkpoint(Vector2(2440,560))
            if age<=5:
                player.guide_to(Vector2(2820,440))

func _update_story()->void:
    match stage:
        0:
            if player.global_position.distance_to(miro.global_position)<92:
                player.stop_guide();stage=1
                _dialogue(["I knew Luma would find someone.","Look around. Veyr didn't cut these trees down — he erased the idea of a tree.","I can't remember what one looked like. Can you invent it again?"],"MIRO",_ask_tree)
        2:
            if player.global_position.distance_to(pip.global_position)<92:
                player.stop_guide();stage=3
                _dialogue(["You made those trees? They keep following the road!","But look up... I know there used to be something above us. Big. Endless.","What do YOU think the sky should look like?"],"PIP",_ask_sky)
        4:
            if player.global_position.x>1290:
                player.stop_guide();stage=5
                _dialogue(["The road ends here.","Don't search for the old bridge. Veyr erased it.","Draw one clear path from the LEFT BANK to the RIGHT BANK. You will walk on the exact line you draw."],"LUMA",_ask_bridge)
        6:
            if player.global_position.x>1725:
                player.stop_guide();stage=7
                world.set_anomaly(3)
                _dialogue(["It worked because YOU made it work.","Look down... something under the water copied your bridge.","Those scratches ahead aren't from the river. Draw something you can defend yourself with."],"LUMA",_ask_sword)
        8:
            enemies=enemies.filter(func(e):return is_instance_valid(e))
            if enemies.is_empty():
                stage=9;controls.show_attack=false
                _dialogue(["They're not monsters. They're pieces of things Veyr erased.","Something small is hiding ahead. It remembers you before you've even met it.","Give it a shape."],"LUMA",_ask_dog)
        10:
            if player.global_position.distance_to(Vector2(2420,545))<90:
                secret_found=true;stage=11
                if is_instance_valid(companion):companion.stop_sniff()
                _dialogue(["A Memory Fragment!","It says: 'The First Scribble was not born evil. It became afraid of being erased.'","Veyr never told anyone that."],"LUMA",func():_set_stage(11))
        11:
            if player.global_position.x>2760:
                player.stop_guide();stage=12;_final_scene()

func _ask_tree()->void:
    _set_stage(1);_open_draw("tree","REIMAGINE A TREE","There is no correct tree. Draw yours.",[Color("#30303a"),Color("#4aa96c"),Color("#8b5a3c"),Color("#f6c344")],func(d):tree_data=d;world.restore_tree(d);_tree_reaction())
func _tree_reaction()->void:
    _play_sfx(SFX_SPARK,.62)
    miro.walk_to(Vector2(560,745));await get_tree().create_timer(1.0).timeout
    world.set_anomaly(1)
    _dialogue(["Shade... I remember shade!","That's not the tree that used to be here. It's better. It's yours.","Wait. That branch just leaned toward the road by itself.","Keep going. The Vale is learning your drawing."],"MIRO",func():_set_stage(2))
func _ask_sky()->void:
    _set_stage(3);_open_draw("sky","REIMAGINE THE SKY","Draw clouds, stars, a sun — whatever belongs above your world.",[Color("#4a90e2"),Color("#f6c344"),Color("#f4f0e6"),Color("#9b6de3"),Color("#f58ab2")],func(d):sky_data=d;world.restore_sky(d);world.set_anomaly(2);backdrop.sky_data=d;backdrop.sky_restored=true;_dialogue(["Whoa... it's moving.","Your sky isn't a picture. The Vale is actually using it.","Maker... one of those shapes just moved against the wind."],"PIP",func():_set_stage(4)))
func _ask_bridge()->void:
    _set_stage(5);_open_draw("bridge","DRAW A BRIDGE","Connect LEFT BANK to RIGHT BANK. Your line becomes the path you walk.",[Color("#30303a"),Color("#8b5a3c"),Color("#f6c344")],func(d):bridge_data=d;world.register_bridge(d);_set_stage(6))
func _ask_sword()->void:
    _set_stage(7);_open_draw("sword","CREATE YOUR WEAPON","Longer drawings have longer reach. Make something you want your hero to carry.",[Color("#30303a"),Color("#ef6b6b"),Color("#9b6de3"),Color("#f6c344"),Color("#4a90e2")],func(d):sword_data=d;player.equip_sword(d);controls.show_attack=true;_spawn_fight())
func _spawn_fight()->void:
    stage=8;_set_stage(8)
    var count:=1 if age<=5 else (2 if age<=8 else 3)
    for i in range(count):
        var e:=EnemyScript.new();e.position=Vector2(1860+i*85,700+(i%2)*90);e.setup(player,age);e.defeated.connect(func(_enemy):_toast("The ink breaks apart into harmless Memory Dust."));world_root.add_child(e);enemies.append(e)
    if age<=5:player.guide_to(Vector2(1835,755))
func _ask_dog()->void:
    _open_draw("dog","DRAW A COMPANION","Dog, fox, blob, dragon... anything can be your friend.",[Color("#30303a"),Color("#8b5a3c"),Color("#f6c344"),Color("#ef6b6b"),Color("#4a90e2")],func(d):dog_data=d;companion=CompanionScript.new();companion.setup(player,d);companion.position=player.position+Vector2(-55,35);world_root.add_child(companion);_set_stage(10))

func _final_scene()->void:
    state="dialogue";controls.enabled_controls=false;player.input_enabled=false
    _dialogue(["So Luma found another Maker.","Every line you restore wakes the paper beneath us.","I did not erase this world because I hate imagination.","I erased it because something inside the paper learned how to erase US.","The question Luma never asked is the only one that matters: who erased first?","Keep drawing, Maker. Soon it will draw back."],"VEYR",_alpha_end)
func _alpha_end()->void:
    state="end"
    var p:=Panel.new();p.position=Vector2(330,180);p.size=Vector2(620,360);p.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")));overlay_layer.add_child(p)
    var t:=Label.new();t.text="ACT I COMPLETE";t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;t.add_theme_font_size_override("font_size",34);t.position=Vector2(20,35);t.size=Vector2(580,50);p.add_child(t)
    var txt:=Label.new();txt.text="You restored a tree, a sky and a road across the river.\nYou created a weapon and a companion.\n\nBut Veyr says every creation is waking the First Scribble...";txt.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;txt.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;txt.position=Vector2(55,105);txt.size=Vector2(510,125);txt.add_theme_font_size_override("font_size",18);p.add_child(txt)
    var again:=_game_button("PLAY AGAIN",Vector2(90,260),Vector2(190,56),Color("#f2c85c"));again.pressed.connect(_begin_game);p.add_child(again)
    var home:=_game_button("HOME",Vector2(340,260),Vector2(190,56),Color("#d9d5ca"));home.pressed.connect(_show_title);p.add_child(home)

# -----------------------------------------------------------------------------
# INTERACTION / UI
# -----------------------------------------------------------------------------
func _update_near_action()->void:
    if not is_instance_valid(controls):return
    controls.interact_label="TALK"
    var nearest:SparkNPC=null;var best:=999.0
    for n in get_tree().get_nodes_in_group("npcs"):
        var d:=player.global_position.distance_to(n.global_position)
        if d<best:best=d;nearest=n
    if not tree_data.is_empty():
        for p in world.grove_points:
            var d:=player.global_position.distance_to(p)
            if d<78 and d<best:best=d;nearest=null;controls.interact_label="SHAKE"
    if best>95:controls.interact_label="LOOK"

func _interact()->void:
    if state!="playing":return
    var best:=999.0;var npc:SparkNPC=null
    for n in get_tree().get_nodes_in_group("npcs"):
        var d:=player.global_position.distance_to(n.global_position)
        if d<best:best=d;npc=n
    if best<95 and is_instance_valid(npc):npc.interact();return
    if not tree_data.is_empty():
        for p in world.grove_points:
            if player.global_position.distance_to(p)<78:
                if not tree_rewarded:tree_rewarded=true;_toast("Your tree drops a Memory Fruit. +1 heart");player.heal(1)
                else:_toast("The leaves sound exactly like your drawing looks.")
                return
    _toast("Luma: Keep following the pale road.")

func _npc_interact(npc)->void:
    if npc==miro:
        if tree_data.is_empty():_dialogue(["The grove is waiting for a Maker."],"MIRO")
        else:_dialogue(["I've been sitting under your tree. It feels different every time the wind moves through it."],"MIRO")
    elif npc==pip:
        if sky_data.is_empty():_dialogue(["Do you think the sky used to have a colour?"],"PIP")
        else:_dialogue(["I like your sky. I saw one of its shapes move when you weren't looking."],"PIP")

func _build_dialogue()->void:
    dialogue_panel=Panel.new();dialogue_panel.position=Vector2(190,510);dialogue_panel.size=Vector2(900,170);dialogue_panel.add_theme_stylebox_override("panel",_panel_box(Color(1,1,.97,.94)));overlay_layer.add_child(dialogue_panel)
    dialogue_name=Label.new();dialogue_name.position=Vector2(26,18);dialogue_name.size=Vector2(200,30);dialogue_name.add_theme_font_size_override("font_size",17);dialogue_name.add_theme_color_override("font_color",Color("#7a5a91"));dialogue_panel.add_child(dialogue_name)
    dialogue_text=Label.new();dialogue_text.position=Vector2(26,48);dialogue_text.size=Vector2(730,92);dialogue_text.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;dialogue_text.add_theme_font_size_override("font_size",20);dialogue_text.add_theme_color_override("font_color",Color("#2f3145"));dialogue_panel.add_child(dialogue_text)
    dialogue_button=_game_button("NEXT",Vector2(770,88),Vector2(105,54),Color("#f2c85c"));dialogue_button.pressed.connect(_advance_dialogue);dialogue_panel.add_child(dialogue_button)

func _dialogue(lines:Array,speaker:String="LUMA",after:Callable=Callable())->void:
    if is_instance_valid(dialogue_panel):_retire(dialogue_panel)
    state="dialogue"
    if is_instance_valid(player):
        player.input_enabled=false
    if is_instance_valid(controls):controls.enabled_controls=false
    dialogue_lines=lines;dialogue_index=0;dialogue_after=after;dialogue_timer=3.1;_build_dialogue();dialogue_name.text=speaker;dialogue_text.text=str(dialogue_lines[0]);dialogue_button.text="CONTINUE" if lines.size()==1 else "NEXT";_play_sfx(SFX_LUMA,.24)

func _advance_dialogue()->void:
    if state!="dialogue":return
    dialogue_index+=1
    if dialogue_index<dialogue_lines.size():
        dialogue_text.text=str(dialogue_lines[dialogue_index]);dialogue_timer=3.1;dialogue_button.text="CONTINUE" if dialogue_index==dialogue_lines.size()-1 else "NEXT";_play_sfx(SFX_LUMA,.22);return
    if is_instance_valid(dialogue_panel):_retire(dialogue_panel)
    state="playing"
    if is_instance_valid(player):
        player.input_enabled=true
    if is_instance_valid(controls):controls.enabled_controls=true
    var cb:=dialogue_after;dialogue_after=Callable()
    if cb.is_valid():cb.call()

func _open_draw(kind:String,prompt:String,hint:String,palette:Array,done_cb:Callable)->void:
    state="drawing"
    if is_instance_valid(player):
        player.input_enabled=false
    if is_instance_valid(controls):controls.enabled_controls=false
    var d:=DrawPadScript.new();overlay_layer.add_child(d);d.setup(kind,prompt,hint,age,palette)
    d.cancelled.connect(func():state="playing";player.input_enabled=true;controls.enabled_controls=true)
    d.finished.connect(func(_kind,data):state="playing";player.input_enabled=true;controls.enabled_controls=true;_play_sfx(SFX_CREATE,.55);done_cb.call(data))

func _pause()->void:
    if state!="playing":return
    state="paused";player.input_enabled=false;controls.enabled_controls=false
    pause_root=Control.new();pause_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);overlay_layer.add_child(pause_root)
    var p:=Panel.new();p.position=Vector2(415,220);p.size=Vector2(450,270);p.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")));pause_root.add_child(p)
    var t:=Label.new();t.text="PAUSED";t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;t.add_theme_font_size_override("font_size",30);t.position=Vector2(20,30);t.size=Vector2(410,45);p.add_child(t)
    var resume:=_game_button("RESUME",Vector2(115,95),Vector2(220,55),Color("#f2c85c"));resume.pressed.connect(func():pause_root.queue_free();state="playing";player.input_enabled=true;controls.enabled_controls=true);p.add_child(resume)
    var home:=_game_button("HOME",Vector2(115,165),Vector2(220,55),Color("#ddd8cb"));home.pressed.connect(_show_title);p.add_child(home)

func _update_hud()->void:
    if not is_instance_valid(health_label):return
    health_label.text="❤ "+str(player.health)+" / "+str(player.max_health)
func _banner(title:String,obj:String)->void:
    if not is_instance_valid(stage_label):return
    stage_label.text=title;objective_label.text=obj;stage_label.modulate.a=1;objective_label.modulate.a=1;stage_banner_timer=2.4
func _toast(text:String)->void:
    if not is_instance_valid(toast_label):return
    toast_label.text=text;toast_label.modulate.a=1
    var tw:=create_tween();tw.tween_interval(2.3);tw.tween_property(toast_label,"modulate:a",0.0,.7)

func _play_sfx(stream:AudioStream,volume:float=1.0)->void:
    if stream==null:return
    var p:=AudioStreamPlayer.new()
    p.stream=stream
    p.volume_db=linear_to_db(clamp(volume,.01,1.0))
    add_child(p)
    p.finished.connect(p.queue_free)
    p.play()

func _clear_game()->void:
    if is_instance_valid(world_root):world_root.queue_free()
    world_root=null;player=null;world=null;controls=null;camera=null;miro=null;pip=null;companion=null;enemies.clear()

func _choice_pick(root:Control,on_pick:Callable,value)->void:
    if is_instance_valid(root): root.queue_free()
    if on_pick.is_valid(): on_pick.call(value)

func _choice_panel(title:String,desc:String,options:Array,on_pick:Callable,on_back:Callable)->Control:
    var root:=Control.new();root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT);overlay_layer.add_child(root)
    var p:=Panel.new();p.position=Vector2(0,0);p.size=Vector2(620,330);p.add_theme_stylebox_override("panel",_panel_box(Color("#fffdf6")));root.add_child(p)
    var t:=Label.new();t.text=title;t.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;t.add_theme_font_size_override("font_size",27);t.position=Vector2(25,28);t.size=Vector2(570,40);p.add_child(t)
    var d:=Label.new();d.text=desc;d.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;d.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER;d.position=Vector2(55,80);d.size=Vector2(510,80);d.add_theme_font_size_override("font_size",17);p.add_child(d)
    for i in options.size():
        var o=options[i]
        var b:=_game_button(str(o.label),Vector2(180,180+i*60),Vector2(260,50),Color("#f2c85c"))
        b.pressed.connect(_choice_pick.bind(root,on_pick,o.value))
        p.add_child(b)
    return root
func _game_button(txt:String,pos:Vector2,sz:Vector2,c:Color)->Button:
    var b:=Button.new();b.text=txt;b.position=pos;b.size=sz;b.focus_mode=Control.FOCUS_NONE;b.add_theme_font_size_override("font_size",17)
    var sb:=StyleBoxFlat.new();sb.bg_color=c;sb.corner_radius_top_left=18;sb.corner_radius_top_right=18;sb.corner_radius_bottom_left=18;sb.corner_radius_bottom_right=18;sb.border_width_left=2;sb.border_width_right=2;sb.border_width_top=2;sb.border_width_bottom=2;sb.border_color=Color("#484b60");b.add_theme_stylebox_override("normal",sb);var h:=sb.duplicate();h.bg_color=c.lightened(.08);b.add_theme_stylebox_override("hover",h);return b
func _panel_box(c:Color)->StyleBoxFlat:
    var s:=StyleBoxFlat.new();s.bg_color=c;s.corner_radius_top_left=24;s.corner_radius_top_right=24;s.corner_radius_bottom_left=24;s.corner_radius_bottom_right=24;s.border_width_left=2;s.border_width_right=2;s.border_width_top=2;s.border_width_bottom=2;s.border_color=Color("#d1cbbb");return s
