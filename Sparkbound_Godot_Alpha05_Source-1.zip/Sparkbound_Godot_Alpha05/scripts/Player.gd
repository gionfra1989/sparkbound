class_name SparkPlayer
extends CharacterBody2D

signal fell
signal health_changed(value:int)
signal attacked

var age := 8
var guided := false
var input_enabled := true
var external_input := Vector2.ZERO
var speed := 260.0
var accel := 1450.0
var friction := 1750.0
var facing := Vector2.RIGHT
var health := 5
var max_health := 5

# Top-down game with a visual jump. The collision body remains on the ground so
# movement, attack and jump can all happen simultaneously on touch screens.
var jump_height := 0.0
var jump_velocity := 0.0
var jumping := false
var attack_timer := 0.0
var invuln := 0.0
var bob_time := 0.0
var run_dust_timer := 0.0

var hero_data: Dictionary = {}
var hero_preset := 0
var sword_data: Dictionary = {}
var has_sword := false
var checkpoint := Vector2.ZERO
var guided_target := Vector2.ZERO
var guided_active := false

func _ready() -> void:
    collision_layer = 1
    collision_mask = 1
    var cs := CollisionShape2D.new()
    var sh := CapsuleShape2D.new()
    sh.radius = 18
    sh.height = 44
    cs.shape = sh
    add_child(cs)
    checkpoint = position
    add_to_group("player")
    queue_redraw()

func configure(p_age:int, p_hero_data:Dictionary = {}, preset:int = 0) -> void:
    age = p_age
    guided = age <= 5
    hero_data = p_hero_data.duplicate(true)
    hero_preset = preset
    if age <= 5:
        max_health = 7; speed = 205.0
    elif age <= 8:
        max_health = 6; speed = 250.0
    elif age <= 10:
        max_health = 5; speed = 270.0
    else:
        max_health = 5; speed = 290.0
    health = max_health
    queue_redraw()

func set_external_input(v:Vector2) -> void:
    external_input = v.limit_length(1.0)

func set_checkpoint(p:Vector2) -> void:
    checkpoint = p

func guide_to(p:Vector2) -> void:
    guided_target = p
    guided_active = true

func stop_guide() -> void:
    guided_active = false

func _physics_process(delta:float) -> void:
    bob_time += delta
    run_dust_timer = max(0.0, run_dust_timer - delta)
    attack_timer = max(0.0, attack_timer - delta)
    invuln = max(0.0, invuln - delta)

    var dir := Vector2.ZERO
    if input_enabled:
        dir = external_input
        var keyboard := Input.get_vector("move_left", "move_right", "move_up", "move_down")
        if keyboard.length() > .1:
            dir = keyboard
        if guided and guided_active and external_input.length() < .12:
            var delta_target := guided_target - global_position
            if delta_target.length() > 24:
                dir = delta_target.normalized()
            else:
                guided_active = false

    if dir.length() > .05:
        velocity = velocity.move_toward(dir.normalized() * speed, accel * delta)
        facing = dir.normalized()
        if run_dust_timer <= 0.0:
            run_dust_timer = .12
    else:
        velocity = velocity.move_toward(Vector2.ZERO, friction * delta)

    move_and_slide()

    if jumping:
        jump_velocity += 1500.0 * delta
        jump_height -= jump_velocity * delta
        if jump_height >= 0.0:
            jump_height = 0.0
            jump_velocity = 0.0
            jumping = false

    queue_redraw()

func do_jump() -> void:
    if jumping or not input_enabled: return
    jumping = true
    jump_velocity = -610.0

func do_attack() -> void:
    if not has_sword or attack_timer > 0.0 or not input_enabled: return
    attack_timer = .34
    attacked.emit()

    var attack_range := 108.0
    if not sword_data.is_empty():
        var bounds:Array = sword_data.get("bounds", [0,0,1,1])
        if bounds.size() >= 4:
            attack_range = 88.0 + abs(float(bounds[2]) - float(bounds[0])) * 110.0

    for enemy in get_tree().get_nodes_in_group("enemies"):
        if not is_instance_valid(enemy): continue
        var delta_enemy:Vector2 = enemy.global_position - global_position
        if delta_enemy.length() < attack_range and delta_enemy.normalized().dot(facing) > -.10 and enemy.has_method("take_hit"):
            enemy.take_hit(1, facing * 175.0)
    queue_redraw()

func equip_sword(data:Dictionary) -> void:
    sword_data = data.duplicate(true)
    has_sword = true
    queue_redraw()

func take_damage(amount:int, knock:=Vector2.ZERO) -> void:
    if invuln > 0.0: return
    health = max(0, health - amount)
    invuln = 1.0
    velocity += knock
    health_changed.emit(health)
    if health <= 0:
        await get_tree().create_timer(.35).timeout
        respawn()
    queue_redraw()

func heal(value:int) -> void:
    health = min(max_health, health + value)
    health_changed.emit(health)
    queue_redraw()

func respawn() -> void:
    global_position = checkpoint
    velocity = Vector2.ZERO
    health = max_health
    invuln = 1.2
    fell.emit()
    health_changed.emit(health)

func _draw() -> void:
    var visual_y := -jump_height
    var shadow_scale := clamp(1.0 - jump_height / 250.0, .55, 1.0)
    _ellipse(Vector2(0, 21), Vector2(27 * shadow_scale, 8 * shadow_scale), Color(.08, .09, .14, .14))

    if velocity.length() > 120 and not jumping:
        var behind := -facing * 22 + Vector2(0, 20)
        draw_circle(behind + Vector2(-5, 0), 4, Color(.62, .58, .50, .16))
        draw_circle(behind + Vector2(7, 2), 3, Color(.62, .58, .50, .12))

    var bounce := sin(bob_time * 11.0) * 2.2 if velocity.length() > 25 else sin(bob_time * 3.0) * 1.0
    var root := Vector2(0, -15 + visual_y + bounce)

    if hero_data.is_empty():
        _draw_preset(root)
    else:
        _draw_custom(root)

    # Spark core – one consistent visual element on every possible hero.
    draw_circle(root + Vector2(0, 4), 6.5, Color("#ffd75c"))
    draw_circle(root + Vector2(0, 4), 11, Color(1, .83, .22, .20), false, 3)

    if has_sword:
        var attack_phase := clamp(1.0 - attack_timer / .34, 0.0, 1.0)
        var swing := -0.75 + attack_phase * 1.20 if attack_timer > 0.0 else -0.55
        var angle := facing.angle() + swing
        draw_set_transform(root + facing * 29, angle, Vector2.ONE)
        _draw_creation(sword_data, Vector2.ZERO, Vector2(112, 44))
        draw_set_transform(Vector2.ZERO, 0, Vector2.ONE)

        if attack_timer > 0.0:
            draw_arc(root + facing * 20, 54, facing.angle() - .85, facing.angle() + .55, 16, Color(1, .86, .36, .45), 5)

func _draw_preset(root:Vector2) -> void:
    var body_colors := [Color("#507fd0"), Color("#52a777"), Color("#d36b58")]
    var color:Color = body_colors[hero_preset % body_colors.size()]

    # Cape/back cloth gives a readable hero silhouette even at phone size.
    var cape_side := -1.0 if facing.x >= 0 else 1.0
    var cape := PackedVector2Array([
        root + Vector2(-8 * cape_side, -9),
        root + Vector2(-27 * cape_side, 10),
        root + Vector2(-19 * cape_side, 35),
        root + Vector2(2 * cape_side, 20)
    ])
    draw_colored_polygon(cape, color.darkened(.30))

    # Boots / walk cycle.
    var step := sin(bob_time * 11.0) * 4.5 if velocity.length() > 25 else 0.0
    draw_line(root + Vector2(-10, 28), root + Vector2(-13 + step, 44), Color("#30354d"), 9, true)
    draw_line(root + Vector2(10, 28), root + Vector2(13 - step, 44), Color("#30354d"), 9, true)
    draw_line(root + Vector2(-17 + step, 44), root + Vector2(-5 + step, 44), Color("#20243a"), 8, true)
    draw_line(root + Vector2(5 - step, 44), root + Vector2(17 - step, 44), Color("#20243a"), 8, true)

    # Tunic + shoulder pieces.
    draw_colored_polygon(PackedVector2Array([
        root + Vector2(-19, -7), root + Vector2(19, -7),
        root + Vector2(17, 31), root + Vector2(-17, 31)
    ]), color)
    draw_circle(root + Vector2(-19, -4), 7, color.lightened(.15))
    draw_circle(root + Vector2(19, -4), 7, color.lightened(.15))

    # Head/hair/eyes.
    draw_circle(root + Vector2(0, -22), 20, Color("#efc29d"))
    draw_arc(root + Vector2(0, -25), 20, PI * 1.05, PI * 1.95, 16, color.darkened(.22), 7)
    draw_circle(root + Vector2(-7, -22), 2.7, Color("#24263a"))
    draw_circle(root + Vector2(7, -22), 2.7, Color("#24263a"))

    # Tiny scarf direction makes the character feel in motion.
    draw_line(root + Vector2(0, -4), root - facing * 22 + Vector2(0, -2), Color("#f2cc57"), 5, true)

func _draw_custom(root:Vector2) -> void:
    # The child's actual drawing is never replaced by a stock body. Animated
    # limbs and a shadow are added around it so it feels alive while preserving
    # the original creation.
    _draw_creation(hero_data, root, Vector2(86, 96))
    var step := sin(bob_time * 11.0) * 4.0 if velocity.length() > 25 else 0.0
    draw_line(root + Vector2(-12, 35), root + Vector2(-15 + step, 48), Color("#34364a"), 7, true)
    draw_line(root + Vector2(12, 35), root + Vector2(15 - step, 48), Color("#34364a"), 7, true)

func _draw_creation(data:Dictionary, center:Vector2, draw_size:Vector2) -> void:
    for st in data.get("strokes", []):
        var pts:Array = st.get("points", [])
        if pts.size() < 2: continue
        var poly := PackedVector2Array()
        for p:Vector2 in pts:
            poly.append(center + Vector2((p.x - .5) * draw_size.x, (p.y - .5) * draw_size.y))
        var color := Color.from_string(str(st.get("color", "#333333")), Color("#333333"))
        draw_polyline(poly, color, clamp(float(st.get("width", 8)) * .33, 2.0, 9.0), true)

func _ellipse(center:Vector2, radii:Vector2, color:Color) -> void:
    var points := PackedVector2Array()
    for i in range(24):
        var angle := TAU * i / 24.0
        points.append(center + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
    draw_colored_polygon(points, color)
