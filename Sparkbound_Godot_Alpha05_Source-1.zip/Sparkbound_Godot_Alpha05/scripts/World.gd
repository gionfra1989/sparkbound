class_name SparkWorld
extends Node2D

# Alpha 0.5 deliberately keeps ONE readable adventure region. The road is broad,
# continuous and easy to follow; creations are the only colourful things that
# become prominent as the player restores the White Vale.

var world_size := Vector2(3600, 1500)
var tree_data: Dictionary = {}
var sky_data: Dictionary = {}
var bridge_data: Dictionary = {}
var bridge_points := PackedVector2Array()
var tree_nodes: Array[Creation] = []
var time := 0.0
var restored_glow := 0.0
var anomaly_level := 0

# One clear road with gentle turns. It never doubles back or becomes a maze.
var road_points := PackedVector2Array([
    Vector2(170, 1060), Vector2(470, 1000), Vector2(760, 930),
    Vector2(1030, 900), Vector2(1270, 850), Vector2(1410, 830),
    Vector2(1740, 830), Vector2(1980, 770), Vector2(2240, 700),
    Vector2(2520, 625), Vector2(2830, 560), Vector2(3150, 500),
    Vector2(3440, 455)
])

# The player must actually cross this water on their drawn bridge.
var river_rect := Rect2(1450, 0, 250, 1500)
var grove_points := [
    Vector2(530, 790), Vector2(690, 1050), Vector2(850, 760),
    Vector2(1020, 980), Vector2(1900, 700), Vector2(2200, 805),
    Vector2(2570, 585), Vector2(2960, 535)
]

func _ready() -> void:
    z_index = -5
    _make_bounds()
    queue_redraw()

func _process(delta: float) -> void:
    time += delta
    restored_glow = move_toward(restored_glow, 1.0 if not tree_data.is_empty() else 0.0, delta * .16)
    queue_redraw()

func _make_bounds() -> void:
    var rects := [
        Rect2(-80, -80, world_size.x + 160, 80),
        Rect2(-80, world_size.y, world_size.x + 160, 80),
        Rect2(-80, 0, 80, world_size.y),
        Rect2(world_size.x, 0, 80, world_size.y)
    ]
    for r in rects:
        var body := StaticBody2D.new()
        body.position = r.position + r.size * .5
        var cs := CollisionShape2D.new()
        var shape := RectangleShape2D.new()
        shape.size = r.size
        cs.shape = shape
        body.add_child(cs)
        add_child(body)

func _draw() -> void:
    # White paper world.
    draw_rect(Rect2(Vector2.ZERO, world_size), Color("#f9f6ed"), true)

    # Very subtle paper fibers only; the landscape stays intentionally empty.
    for y in range(70, int(world_size.y), 125):
        draw_line(Vector2(0, y), Vector2(world_size.x, y + sin(float(y) * .012) * 6.0), Color(0.55, .52, .47, .055), 1.0)

    # A soft memory glow returns along the route after the first creation.
    if restored_glow > 0.0:
        for p in road_points:
            draw_circle(p, 170, Color(.53, .78, .58, .025 * restored_glow))

    # One road, one continuous ribbon. No second wide stroke is painted on top,
    # so the path never reads as duplicated or overlapping.
    # Exactly one road ribbon. No duplicate outline/underlay is drawn.
    draw_polyline(road_points, Color("#eadfbe"), 104, true)

    # Sparse stones guide the eye without turning the road into UI.
    for i in range(1, road_points.size() - 1):
        var p := road_points[i]
        draw_circle(p + Vector2(0, 42), 4.5, Color("#c1b69e"))

    # River = actual gameplay hazard.
    var water := Color("#ecece8") if sky_data.is_empty() else Color("#78c9e7")
    draw_rect(river_rect, water, true)
    for yy in range(35, int(world_size.y), 58):
        var phase := sin(time * 1.15 + float(yy) * .03) * 8.0
        draw_line(Vector2(river_rect.position.x + 18, yy), Vector2(river_rect.end.x - 18, yy + phase), Color(1, 1, 1, .34), 3.0, true)
    draw_line(Vector2(river_rect.position.x, 0), Vector2(river_rect.position.x, world_size.y), Color("#aaa698"), 6.0)
    draw_line(Vector2(river_rect.end.x, 0), Vector2(river_rect.end.x, world_size.y), Color("#aaa698"), 6.0)

    # Story landmarks are small and readable rather than big fake scenery.
    _sign(Vector2(560, 690), "FORGOTTEN GROVE")
    _sign(Vector2(1110, 710), "MEMORY HILL")
    _sign(Vector2(1850, 675), "WHITE ROAD")
    _sign(Vector2(3060, 405), "OLD GATE")

    # Residual eraser marks hint that whole objects are missing.
    for p in [Vector2(830, 720), Vector2(1120, 900), Vector2(2400, 610), Vector2(3240, 455)]:
        draw_arc(p, 32, 0, TAU, 22, Color(.42, .40, .38, .12), 2.0)

    # The mystery escalates using tiny visual echoes, not extra mechanics.
    # They are deliberately subtle: children notice that the world is reacting
    # before the story explains why.
    if anomaly_level >= 1:
        draw_arc(Vector2(925, 755), 26, time * .10, time * .10 + PI * 1.55, 20, Color(.16, .14, .22, .22), 3.0)
    if anomaly_level >= 2:
        var echo := PackedVector2Array([Vector2(1195, 675), Vector2(1215, 660), Vector2(1240, 676), Vector2(1265, 655), Vector2(1285, 672)])
        draw_polyline(echo, Color(.15, .13, .20, .22), 3.0, true)
    if anomaly_level >= 3 and bridge_points.size() > 1:
        var echo_bridge := PackedVector2Array()
        for p in bridge_points: echo_bridge.append(p + Vector2(0, 24 + sin(time * 1.7 + p.x * .01) * 3.0))
        draw_polyline(echo_bridge, Color(.12, .10, .17, .16), 4.0, true)

    # The bridge on screen IS the longest stroke drawn by the child.
    if bridge_points.size() > 1:
        # Under-shadow improves readability against the water.
        draw_polyline(bridge_points, Color(0.08, .08, .11, .16), 34, true)
        _draw_creation(bridge_data, Vector2(1575, 825), Vector2(360, 205), 1.0)


func set_anomaly(level:int) -> void:
    anomaly_level = max(anomaly_level, level)
    queue_redraw()

func _sign(pos: Vector2, text: String) -> void:
    draw_line(pos + Vector2(0, 22), pos + Vector2(0, 60), Color("#918a7b"), 5, true)
    draw_rect(Rect2(pos + Vector2(-67, -5), Vector2(134, 34)), Color("#eee7d4"), true)
    draw_rect(Rect2(pos + Vector2(-67, -5), Vector2(134, 34)), Color("#a59d8a"), false, 2)
    draw_string(ThemeDB.fallback_font, pos + Vector2(-61, 19), text, HORIZONTAL_ALIGNMENT_CENTER, 122, 13, Color("#555766"))

func restore_tree(data: Dictionary) -> void:
    tree_data = data.duplicate(true)
    for n in tree_nodes:
        if is_instance_valid(n): n.queue_free()
    tree_nodes.clear()
    for i in range(grove_points.size()):
        var creation := Creation.new()
        creation.setup("tree", tree_data, Vector2(122 + (i % 2) * 10, 154 + (i % 3) * 8))
        creation.position = grove_points[i]
        add_child(creation)
        tree_nodes.append(creation)
    queue_redraw()

func restore_sky(data: Dictionary) -> void:
    sky_data = data.duplicate(true)
    queue_redraw()

func register_bridge(data: Dictionary) -> void:
    bridge_data = data.duplicate(true)
    bridge_points = PackedVector2Array()

    # Pick the longest stroke: that is the actual walkable route.
    var best: Array = []
    for st in data.get("strokes", []):
        var pts: Array = st.get("points", [])
        if pts.size() > best.size(): best = pts

    # Map the drawing canvas left-to-right onto the river banks. Y remains
    # meaningful, so a wobbly/curved bridge creates a wobbly/curved path.
    for p: Vector2 in best:
        bridge_points.append(Vector2(
            river_rect.position.x - 24 + p.x * (river_rect.size.x + 48),
            735 + p.y * 190
        ))
    queue_redraw()

func is_water(pos: Vector2) -> bool:
    return river_rect.has_point(pos)

func is_bridge_safe(pos: Vector2) -> bool:
    return bridge_distance(pos) <= 34.0

func bridge_distance(pos: Vector2) -> float:
    if bridge_points.size() < 2: return 99999.0
    var best := 99999.0
    for i in range(1, bridge_points.size()):
        best = min(best, _dist_segment(pos, bridge_points[i - 1], bridge_points[i]))
    return best

func bridge_closest_point(pos: Vector2) -> Vector2:
    if bridge_points.size() < 2: return pos
    var best_point := bridge_points[0]
    var best_distance := INF
    for i in range(1, bridge_points.size()):
        var candidate := _project_segment(pos, bridge_points[i - 1], bridge_points[i])
        var d := pos.distance_squared_to(candidate)
        if d < best_distance:
            best_distance = d
            best_point = candidate
    return best_point

func bridge_has_full_crossing() -> bool:
    if bridge_points.size() < 2: return false
    var min_x := INF
    var max_x := -INF
    for p in bridge_points:
        min_x = min(min_x, p.x)
        max_x = max(max_x, p.x)
    return min_x <= river_rect.position.x + 8 and max_x >= river_rect.end.x - 8

func _project_segment(p: Vector2, a: Vector2, b: Vector2) -> Vector2:
    var ab := b - a
    var den := ab.length_squared()
    if den < .001: return a
    var q := clamp((p - a).dot(ab) / den, 0.0, 1.0)
    return a + ab * q

func _dist_segment(p: Vector2, a: Vector2, b: Vector2) -> float:
    return p.distance_to(_project_segment(p, a, b))

func _draw_creation(data: Dictionary, center: Vector2, draw_size: Vector2, alpha: float) -> void:
    for st in data.get("strokes", []):
        var pts: Array = st.get("points", [])
        if pts.size() < 2: continue
        var poly := PackedVector2Array()
        for p: Vector2 in pts:
            poly.append(center + Vector2((p.x - .5) * draw_size.x, (p.y - .5) * draw_size.y))
        var color := Color.from_string(str(st.get("color", "#333333")), Color("#333333"))
        color.a *= alpha
        draw_polyline(poly, color, clamp(float(st.get("width", 8)) * .34, 2.0, 11.0), true)
